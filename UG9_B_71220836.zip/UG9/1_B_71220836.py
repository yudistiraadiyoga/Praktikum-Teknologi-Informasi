print ('========== ALAT PENGHITUNG LINGKARAN SENTOT ==========')
d = int(input('Masukkan Diameter (Meter) :'))
phi = 3.14
t = (phi*d)
print('Jarak yang harus di tempuh :',t)
