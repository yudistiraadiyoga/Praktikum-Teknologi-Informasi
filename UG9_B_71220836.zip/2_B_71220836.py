print ('========== INI PROGRAM SEDER HANA =========')
print ('Masukkan Angka yang ingin di Pangkatkan :')
a = int(input(''))
pangkat = a**7
print ('Angka anda telah dipangkat kan 7! anda mendapat angkat:',pangkat)
