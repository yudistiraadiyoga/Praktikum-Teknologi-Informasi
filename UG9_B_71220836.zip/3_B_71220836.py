print ("========== CATATAN BELANJA ==========")
mylist1 = ['sikat Gigi', 'Odol', 'Shampo', 'Sabun', 'Ciduk']
mylist2 = ['Teh', 'Gula', 'Garam', 'Micin', 'Kecap']
print ("========== Daftar 1 ==========")
print ("Daftar belanja 1:",mylist1)

print ("========== Daftar 2 ==========")
print ("Daftar belanja 2:",mylist2)

print ("Jawab dengan angka [1/2]")
print ("1.Rubah Belanjaan")
print ("2.Keluar")
a = int(input('masukkan pilihan:'))
if a == 2:
    print ('out')
else:
    if a == 1:
        daftar1 = input('Masukkan nama item ke daftar 1 :')
        index1 = int(input('Masukkan index yang ingin diubah :'))
        mylist1[index1]=daftar1
        daftar2 = input('Masukkan nama item ke daftar 2 :')
        index2 = int(input('Masukkan index yang ingin diubah :'))
        mylist2[index2]=daftar2

        print ("========== Daftar 1 ==========")
        print ("Daftar belanja 1:",mylist1)

        print ("========== Daftar 2 ==========")
        print ("Daftar belanja 2:",mylist2)
    else:
        print('wrong input')
